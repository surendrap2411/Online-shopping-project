package com.example.Online_shopping_project.Entity;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED
}