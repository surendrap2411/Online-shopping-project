package com.example.Online_shopping_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShoppingProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineShoppingProjectApplication.class, args);
	}

}
