package com.example.Online_shopping_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShoppingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
